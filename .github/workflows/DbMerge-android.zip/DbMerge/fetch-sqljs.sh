#!/bin/sh
# یەک جار جێبەجێی بکە (ئینتەرنێت پێویستە) بۆ دابەزاندنی sql.js
cd "$(dirname "$0")/app/src/main/assets/www"
curl -fLO https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/sql-wasm.js
curl -fLO https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/sql-wasm.wasm
ls -la
