هەنگاوەکان بۆ دروستکردنی ئەپی ئەندرۆید (APK)

١. sql.js دابەزێنە (یەک جار):
   - لە تێرمیناڵ: ./fetch-sqljs.sh
   - یان بە دەست: sql-wasm.js و sql-wasm.wasm (وەشانی 1.8.0) دابەزێنە و بیانخە ناو:
     app/src/main/assets/www/
   (ئەمە وا دەکات ئەپەکە بێ ئینتەرنێت کار بکات)

٢. Android Studio بکەرەوە: File > Open > ئەم فۆڵدەرە (DbMerge) هەڵبژێرە.
   چاوەڕێ بکە تا Gradle Sync تەواو دەبێت.

٣. بۆ تاقیکردنەوە: مۆبایلەکەت بە USB ببەستەوە (USB debugging) و Run دابگرە.

٤. بۆ APK: Build > Build APK(s)
   فایلەکە دەبێت لێرە: app/build/outputs/apk/debug/app-debug.apk

٥. بۆ بڵاوکردنەوە لە Play Store: Build > Generate Signed Bundle / APK
   و لە app/build.gradle.kts ئەمانە بگۆڕە:
   - applicationId و namespace (com.example.dbmerge) بۆ ناوی تایبەت بە خۆت
   - versionCode و versionName
   - ئایکۆنی ئەپ: Right-click res > New > Image Asset

تێبینی: فایلی دەرچوو لە فۆڵدەری Downloads پاشەکەوت دەکرێت (Android 10 و سەرووتر).
ڕووکارەکە لە app/src/main/assets/www/index.html ـە و دەتوانیت لەوێ دەستکاری بکەیت.
